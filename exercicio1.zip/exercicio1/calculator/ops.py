def add(arg1, arg2):
    return arg1 + arg2


def sub(arg1, arg2):
    return arg1 - arg2


def mult(arg1, arg2):
    return arg1 * arg2


def div(arg1, arg2):
    return arg1 / arg2
